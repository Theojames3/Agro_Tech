document.getElementById('sendBtn').addEventListener('click', function () {
    const userInput = document.getElementById('userInput').value;
    fetch('/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userInput })
    })
        .then(response => response.json())
        .then(data => {
            const messages = document.getElementById('messages');
            messages.innerHTML += `<p>You: ${userInput}</p>`;
            messages.innerHTML += `<p>Bot: ${data.reply}</p>`;
            document.getElementById('userInput').value = '';
        });
});
